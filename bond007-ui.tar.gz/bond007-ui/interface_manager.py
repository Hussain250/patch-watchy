import threading
import liaison_client
import time
import json
import os
import subprocess
import re
from lib2to3.pgen2.tokenize import Operator
from ui_logger import uilogger
from liaison_client import clientlist
from compiler.ast import Sub
import psutil
import socket
import netaddr
from netaddr import IPNetwork, IPAddress

NETWORK_INTERFACE_FILE = '/etc/network/interfaces.d'
APP_DIR = os.path.dirname(os.path.abspath(__file__))
SCRIPT_FOLDER = APP_DIR + '/scripts/'
dhcp_file_size = None
ip_address = None
host_name = None
hardware_address = None
BOND007_INTERFACE = 'p2p1'
ethernet_interface = BOND007_INTERFACE
wireless_interface = 'wlan0'
lease_file = '/var/lib/misc/dnsmasq.leases'
lastsample_eth_data = [0, 0]
lastsample_wifi_data = [0, 0]
device_log_directory = '/tmp'
_ui_state = None
_curr_state = None
_dongle_list = {}
balance_info = {'dongle0': {'name': '1', 'operator': None, 'balance': 'N/A'},
                'dongle1': {'name': '2', 'operator': None, 'balance': 'N/A'},
                'dongle2': {'name': '3', 'operator': None, 'balance': 'N/A'},
                'dongle3': {'name': '4', 'operator': None, 'balance': 'N/A'},
                'dongle4': {'name': '5', 'operator': None, 'balance': 'N/A'},
                'dongle5': {'name': '6', 'operator': None, 'balance': 'N/A'},
                'dongle6': {'name': '7', 'operator': None, 'balance': 'N/A'},
                'dongle7': {'name': '8', 'operator': None, 'balance': 'N/A'}}
version = 'N/A'

usage = {'download_speed': '0', 'upload_speed': '0', 'download_data': '0', 'upload_data': '0', 'ip_address': None,
         'host_name': None, 'hardware_address': None}

speed = {'rx_dongle0': '0', 'tx_dongle0': '0',
         'rx_dongle1': '0', 'tx_dongle1': '0',
         'rx_dongle2': '0', 'tx_dongle2': '0',
         'rx_dongle3': '0', 'tx_dongle3': '0',
         'rx_dongle4': '0', 'tx_dongle4': '0',
         'rx_dongle5': '0', 'tx_dongle5': '0',
         'rx_dongle6': '0', 'tx_dongle6': '0',
         'rx_dongle7': '0', 'tx_dongle7': '0',
         'rx': '0', 'tx': '0'}

# dongle_info holds device state and information relating to it.
dongle_info = {
    'dongle0': {'state': 'NO_DEVICE', 'state_id': 'None', 'user_error': None, 'operator': None, 'auto_dial': 'no',
                'balance': None, 'rat': 'N/A', 'device_type' : None, 'interface_name': None, 'ipconflict': None},
    'dongle1': {'state': 'NO_DEVICE', 'state_id': 'None', 'user_error': None, 'operator': None, 'auto_dial': 'no',
                'balance': None, 'rat': 'N/A', 'device_type' : None, 'interface_name': None, 'ipconflict': None},
    'dongle2': {'state': 'NO_DEVICE', 'state_id': 'None', 'user_error': None, 'operator': None, 'auto_dial': 'no',
                'balance': None, 'rat': 'N/A', 'device_type' : None, 'interface_name': None, 'ipconflict': None},
    'dongle3': {'state': 'NO_DEVICE', 'state_id': 'None', 'user_error': None, 'operator': None, 'auto_dial': 'no',
                'balance': None, 'rat': 'N/A', 'device_type' : None, 'interface_name': None, 'ipconflict': None},
    'dongle4': {'state': 'NO_DEVICE', 'state_id': 'None', 'user_error': None, 'operator': None, 'auto_dial': 'no',
                'balance': None, 'rat': 'N/A', 'device_type' : None, 'interface_name': None, 'ipconflict': None},
    'dongle5': {'state': 'NO_DEVICE', 'state_id': 'None', 'user_error': None, 'operator': None, 'auto_dial': 'no',
                'balance': None, 'rat': 'N/A', 'device_type' : None, 'interface_name': None, 'ipconflict': None},
    'dongle6': {'state': 'NO_DEVICE', 'state_id': 'None', 'user_error': None, 'operator': None, 'auto_dial': 'no',
                'balance': None, 'rat': 'N/A', 'device_type' : None, 'interface_name': None, 'ipconflict': None},
    'dongle7': {'state': 'NO_DEVICE', 'state_id': 'None', 'user_error': None, 'operator': None, 'auto_dial': 'no',
                'balance': None, 'rat': 'N/A', 'device_type' : None, 'interface_name': None, 'ipconflict': None}}

# ui_dongle_info holds all data which is passed over to js. This structure holds color
# and what state needs to be displayed on ui.
ui_dongle_info = {'dongle0': {'color': None, 'ui_state': None, 'user_error': None, 'operator': None, 'auto_dial': 'no',
                              'signal': None, 'rat': 'N/A', 'device_type' : None, 'ipconflict': False},
                  'dongle1': {'color': None, 'ui_state': None, 'user_error': None, 'operator': None, 'auto_dial': 'no',
                              'signal': None, 'rat': 'N/A', 'device_type' : None, 'ipconflict': False},
                  'dongle2': {'color': None, 'ui_state': None, 'user_error': None, 'operator': None, 'auto_dial': 'no',
                              'signal': None, 'rat': 'N/A', 'device_type' : None, 'ipconflict': False},
                  'dongle3': {'color': None, 'ui_state': None, 'user_error': None, 'operator': None, 'auto_dial': 'no',
                              'signal': None, 'rat': 'N/A', 'device_type' : None, 'ipconflict': False},
                  'dongle4': {'color': None, 'ui_state': None, 'user_error': None, 'operator': None, 'auto_dial': 'no',
                              'signal': None, 'rat': 'N/A', 'device_type' : None, 'ipconflict': False},
                  'dongle5': {'color': None, 'ui_state': None, 'user_error': None, 'operator': None, 'auto_dial': 'no',
                              'signal': None, 'rat': 'N/A', 'device_type' : None, 'ipconflict': False},
                  'dongle6': {'color': None, 'ui_state': None, 'user_error': None, 'operator': None, 'auto_dial': 'no',
                              'signal': None, 'rat': 'N/A', 'device_type' : None, 'ipconflict': False},
                  'dongle7': {'color': None, 'ui_state': None, 'user_error': None, 'operator': None, 'auto_dial': 'no',
                              'signal': None, 'rat': 'N/A', 'device_type' : None, 'ipconflict': False}}

local_update_folder = '/tmp/local_update/'
local_update_private_key = '/opt/watchy/ssl-keypair/local_update_private.pem'


def get_wan_port_details():
    i = 0
    while i < 8:
        log_file = device_log_directory + '/' + 'port' + str(i)
        dongle_name = 'dongle' + str(i)
        try:
            data = json.load(open(log_file))
            dongle_info[dongle_name]['interface_name'] = data["interface_name"]
            dongle_info[dongle_name]['device_type'] = data["device_type"]
            ui_dongle_info[dongle_name]['device_type'] = data["device_type"]
        except (IOError, ValueError) as e:
            dongle_info[dongle_name]['interface_name'] = None
            dongle_info[dongle_name]['device_type'] = None
            ui_dongle_info[dongle_name]['device_type'] = None
        i = i+1


def restart_device():
    os.system("sudo reboot")


def shutdown_device():
    os.system("sudo shutdown -h now")


def dump_log():
    uilogger.debug(' executing command')
    script_path = SCRIPT_FOLDER + 'log_dump.sh'

    dump_log_process = subprocess.Popen(script_path, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    dump_log_process.wait()
    output, error = dump_log_process.communicate()
    return output


def get_values(interface):
    data = psutil.net_io_counters(pernic=True)[interface]
    value = [data.bytes_sent, data.bytes_recv]
    return value


def getSpeed():
    currentsample_eth_data = get_values(ethernet_interface)
    currentsample_wifi_data = get_values(wireless_interface)
    download = (currentsample_eth_data[0] - lastsample_eth_data[0]) + (
    currentsample_wifi_data[0] - lastsample_wifi_data[0])
    upload = (currentsample_eth_data[1] - lastsample_eth_data[1]) + (
    currentsample_wifi_data[1] - lastsample_wifi_data[1])
    total_download = download * 8
    total_upload = upload * 8
    download_speed = round(total_download / (1000.0 * 1000.0), 2)
    upload_speed = round(total_upload / (1000.0 * 1000.0), 2)
    global lastsample_eth_data
    global lastsample_wifi_data
    lastsample_eth_data = currentsample_eth_data
    lastsample_wifi_data = currentsample_wifi_data

    usage['download_speed'] = upload_speed
    usage['upload_speed'] = download_speed


#    uilogger.debug(download_speed + ' ' + upload_speed)

def getDataUsage():
    eth_data = get_values(ethernet_interface)
    wifi_data = get_values(wireless_interface)
    total_download = eth_data[0] + wifi_data[0]
    total_upload = eth_data[1] + wifi_data[1]
    download_data = round(total_download / (1024.0 * 1024.0 * 1024.0), 2)
    upload_data = round(total_upload / (1024.0 * 1024.0 * 1024.0), 2)

    usage['download_data'] = upload_data
    usage['upload_data'] = download_data


def get_individual_speed():
    return



def format_to_indian(timestamp):
    '''
    timestamp fetched from dhcpd.leases will be like 2014/06/24 06:57:40
    this function replaces the month number by month name 
    '''
    import calendar
    month_number = int(timestamp.split()[0].split('/')[1])
    month_name = calendar.month_name[month_number]

    date = timestamp.split()[0]
    time = timestamp.split()[1]

    date = date.split('/')
    date[1] = month_name
    date = '/'.join(date)

    timestamp = date + ' ' + time

    return timestamp

def get_leased_ip():
    """
    file: /var/lib/misc/dnsmasq.leases
    Example entries in the file:
    1496748310 64:71:32:e9:85:ba 10.0.2.101 watchy-105 *
    1496748310 - expiry time in epoch format
    64:71:32:e9:85:ba - mac address
    10.0.2.101 - leased ip
    watchy-105 client-hostname
    """
    current_log_string = None
    with open(lease_file) as dhcp:
        lease_list = dhcp.readlines()
        for i in range(0, len(lease_list)):
            print lease_list[i]
            line = lease_list[i].split()
            print line
            expiry_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(float(line[0])))
            mac_address = line[1]
            leased_ip = line[2]
            client_hostname = line[3]
            if client_hostname is '*':
                log = 'DEVICE [' + mac_address + '] got ' + leased_ip + ' will expire by ' + expiry_time
            else:
                log = client_hostname + ' [' + mac_address + '] got ' + leased_ip + ' will expire by ' + expiry_time
            if current_log_string:
                current_log_string = current_log_string + log + '<br/>'
            else:
                current_log_string = log + '<br/>'

    return current_log_string


def set_new_tunnel_attributes(dongle_name):
    ui_dongle_info[dongle_name]['color'] = 'green'
    ui_dongle_info[dongle_name]['ui_state'] = 'connected'


def set_tunnel_dropped_attributes(dongle_name):
    ui_dongle_info[dongle_name]['color'] = 'red'
    ui_dongle_info[dongle_name]['ui_state'] = 'retrying'


def set_no_device_attributes(dongle_name):
    ui_dongle_info[dongle_name]['color'] = 'grey'
    ui_dongle_info[dongle_name]['ui_state'] = 'no_device'
    ui_dongle_info[dongle_name]['operator'] = None

def set_new_device_attributes(dongle_name):
    if dongle_info[dongle_name]['user_error']:
        ui_dongle_info[dongle_name]['color'] = 'red'
        ui_dongle_info[dongle_name]['ui_state'] = 'retrying'
    else:
        ui_dongle_info[dongle_name]['color'] = 'yellow'
        ui_dongle_info[dongle_name]['ui_state'] = 'dialing'

def set_ip_dropped_attributes(dongle_name):
    ui_dongle_info[dongle_name]['color'] = 'red'
    ui_dongle_info[dongle_name]['ui_state'] = 'retrying'

def set_new_ip_attributes(dongle_name):
    if dongle_info[dongle_name]['user_error']:
        ui_dongle_info[dongle_name]['color'] = 'red'
        ui_dongle_info[dongle_name]['ui_state'] = 'retrying'
    else:
        ui_dongle_info[dongle_name]['color'] = 'yellow'
        ui_dongle_info[dongle_name]['ui_state'] = 'dialing'

def set_state_attributes(dongle_name):
    uilogger.debug('checking for attributes')
    if dongle_info[dongle_name]['state'] == 'DEVICE_READY':
        set_new_device_attributes(dongle_name)
    elif dongle_info[dongle_name]['state'] == 'IP_READY':
        set_new_ip_attributes(dongle_name)
    elif dongle_info[dongle_name]['state'] == 'TUNNEL_READY':
        set_new_tunnel_attributes(dongle_name)
    elif dongle_info[dongle_name]['state'] == 'NO_DEVICE':
        set_no_device_attributes(dongle_name)
    else:
        set_no_device_attributes(dongle_name)


def currentState(obj, reply):
    sock = list(liaison_client.clientlist.keys())[list(liaison_client.clientlist.values()).index(obj)]
    search = 'dongle'
    index = sock.find(search)
    number = sock[index + 6]
    dongle_name = search + number
    uilogger.debug(dongle_name)
    global _curr_state
    uilogger.debug(reply)
    core_reply = json.loads(reply)
    uilogger.debug('checking the reply')
    try:
        global version
        version = str(core_reply['version'])
        uilogger.info(version)
    except KeyError:
        uilogger.debug('Server didnt sent version')
    try:
        dongle_info[dongle_name]['balance'] = str(core_reply['balance'])
        balance_info[dongle_name]['balance'] = str(core_reply['balance'])
        balance_info[dongle_name]['operator'] = dongle_info[dongle_name]['operator']

    except KeyError:
        uilogger.debug('Server didnt sent balance')

    try:
        core_reply_signal = str(core_reply['signal'])
        if core_reply_signal == 'false':
            signal = None
        else:
            signal = core_reply_signal
        uilogger.debug(signal)
        ui_dongle_info[dongle_name]['signal'] = signal
    except KeyError:
        uilogger.debug('Server didnt sent signal')
    try:
        ipconflict = core_reply['ipconflict']
        if ipconflict is not None:
            ipconflict_with = "dongle" + str(ipconflict)
            ui_dongle_info[ipconflict_with]['ipconflict'] = True
        else:
            ui_dongle_info[dongle_name]['ipconflict'] = False
    except KeyError:
        uilogger.debug('Server did not sent ipconflict')
        ui_dongle_info[dongle_name]['ipconflict'] = False
    try:
        core_reply_rat = str(core_reply['rat'])
        if core_reply_rat != 'CANNOT_GET_RAT':
            rat = core_reply_rat
        else:
            rat = 'N/A'
        ui_dongle_info[dongle_name]['rat'] = rat
    except KeyError:
        uilogger.debug('Server did not sent rat')

    try:
        state = str(core_reply['state'])
        dongle_info[dongle_name]['state'] = state
        if not core_reply['user_error']:
            error = None
        else:
            error = str(core_reply['user_error'])
        ui_dongle_info[dongle_name]['user_error'] = error
        dongle_info[dongle_name]['user_error'] = error
        if not core_reply['operator']:
            operator = None
        else:
            operator = str(core_reply['operator'])
        ui_dongle_info[dongle_name]['operator'] = operator
        dongle_info[dongle_name]['operator'] = operator
        uilogger.info('Recieved state\t operator\t error')
        log_msg = dongle_name + '\t' + str(state) + '\t' + str(operator) + '\t' + str(error)
        uilogger.info(log_msg)
        set_state_attributes(dongle_name)
        uilogger.info('Setting Color:')
        uilogger.info(ui_dongle_info[dongle_name]['color'])
    except KeyError:
        uilogger.debug('No state found')
    uilogger.debug(ui_dongle_info)


def sendToAll(action):
    msg = {}
    msg['action'] = action
    uilogger.info(msg)
    for key in sorted(liaison_client.clientlist.keys()):
        obj = liaison_client.clientlist[key]
        obj.sendMessage(json.dumps(msg))


def send_to(dongle_name, msg):
    if dongle_name is None:
        if len(liaison_client.clientlist.keys()) > 0:
            uilogger.debug(liaison_client.clientlist.keys()[0])
            uilogger.debug(liaison_client.clientlist[liaison_client.clientlist.keys()[0]])
            obj = liaison_client.clientlist[liaison_client.clientlist.keys()[0]]
            obj.sendMessage(json.dumps(msg))
    else:
        client_sock = liaison_client.SOCK_PATH + "/" + dongle_name + '.sock'
        if len(liaison_client.clientlist.keys()) > 0:
            obj = liaison_client.clientlist[client_sock]
            obj.sendMessage(json.dumps(msg))

    if msg["action"] is 'GET_VERSION':
        return version


def send(dongle_name, action, operator_name, auto_dial):
    msg = {}
    uilogger.debug('sending message in seperate thread')
    client_sock = liaison_client.SOCK_PATH + "/" + dongle_name + '.sock'
    uilogger.debug('client_list ' + clientlist)
    uilogger.debug(len(liaison_client.clientlist.keys()))
    if len(liaison_client.clientlist.keys()) > 0:
        obj = liaison_client.clientlist[client_sock]
        if action == 'GET_VERSION':
            msg['action'] = action
        elif action == 'GET_SIGNAL_STRENGTH':
            msg['action'] = action
        elif action == 'GET_DEVICE_INFO':
            msg['action'] = action
        elif action == 'GET_RAT':
            msg['action'] = action
        elif action == 'GET_DATA_BALANCE':
            msg['action'] = action
        else:
            msg = None
        obj.sendMessage(json.dumps(msg))


# def start_liaison_client(reactor):
#     if len(liaison_client.clientlist.keys()) <= 0 :
#        lock = threading.Lock()
#        dm_thread = threading.Thread(target=liaison_client.initialise, name=" 1", args=(lock,reactor,))
#        dm_thread.start()
#        time.sleep(1)


def start_liaison_client(reactor):
    if len(liaison_client.clientlist.keys()) <= 0:
        liaison_client.initialise()


def stop_liaison_client():
    for key in sorted(liaison_client.clientlist.keys()):
        uilogger.debug(key)
        obj = liaison_client.clientlist[key]
        obj.stopConnection()


def get_watchy_app_bundle_version():
    version_for = 'watchy-app-bundle'
    version = os.popen("dpkg -s " + version_for + " | grep 'Version'")
    version_number = version.read().strip('\n')
    version_number = version_number.split()
    version_number = version_number[1]
    return version_number


def get_hostspot_password_strength(password):
    """
    val and gets the strength of the wifi password. logic is
    having a counter variable which will be,
    +1, if password has digit
    +2, if password has [a-z] or [A-Z]
    =0, if password has any special characters

    :param password:
    :return: integer
    """
    uilogger.info('inside getting strength')
    password = str(password)
    uilogger.info(password)
    strength = 0

    if 8 <= len(password) <= 16:

        if not re.match("^[a-zA-Z0-9_]*$", password):
            uilogger.info('has special character')
            strength = 0
            return strength

        if re.search(r'\d', password):
            uilogger.info('has digit')
            strength += 1

        if re.search(r'[A-Z]', password):
            uilogger.info('has upper case')
            strength += 2

        if re.search(r'[a-z]', password):
            uilogger.info('has lower case')
            strength += 2

    uilogger.info(strength)
    return strength


def get_hotspot_details():
    hotspot_status_file_path = '/opt/watchy/bond007-core/conf/hotspot_status'
    get_hotspot = os.popen(SCRIPT_FOLDER + '/hotspot.sh GET')
    hotspot_details = get_hotspot.read().strip('\n')
    hotspot_details = hotspot_details.split('+')
    status = None
    wifi_service_name = 'hostapd'
    service_status = os.system('sudo service' + ' ' + wifi_service_name + ' ' + 'status > /dev/null')
    if service_status == 0:
        status = 'on'
    else:
        status = 'off'
    message = {"ssid": hotspot_details[0], "password": hotspot_details[1], "user_message": None, "status": status}
    return message


def set_hotspot_details(new_ssid, new_password):

    strength = get_hostspot_password_strength(new_password)

    if len(new_password) > 16:
        message = {"ssid": new_ssid, "password": new_password,
                   "user_message": "* Abort. Your password is too long it contains " + str(
                       len(new_password)) + " characters instead of 8-16 characters"}
        return message

    elif strength == 0:
        message = {"ssid": new_ssid, "password": new_password,
                   "user_message": "* Abort. Password should contain 8-16 characters of numbers[0-9] and alphabets[a-z][A-Z]"}
        return message

    elif strength == 1:
        message = {"ssid": new_ssid, "password": new_password,
                   "user_message": "* Abort. Password should contain alphabets[a-z][A-Z] also"}
        return message

    elif strength == 3 or strength == 5:

        set_hotspot = os.popen(SCRIPT_FOLDER + '/hotspot.sh SET ' + new_ssid + ' ' + new_password)
        time.sleep(1)
        message = get_hotspot_details()
        message['user_message'] = "* Password is good"
        return message

    elif strength == 4 or strength == 2:
        message = {"ssid": new_ssid, "password": new_password,
                   "user_message": "* Abort. Password should contain numbers[0-9] also"}
        return message


def reset_hotspot_details():
    reset_hotspot = os.popen(SCRIPT_FOLDER + '/hotspot.sh RESET')
    time.sleep(1)
    return get_hotspot_details()


def get_serial_number():
    serial_number_file = "/opt/watchy/bond007-id/serial.number"
    f = open(serial_number_file)
    serial_number = f.read().split()[0]
    return serial_number


def is_decrypted():
    uilogger.info('is_decrypted?')
    file = [f for f in os.listdir(local_update_folder) if os.path.isfile(os.path.join(local_update_folder, f))][0]
    uilogger.info(local_update_private_key)
    bundle = local_update_folder + file
    key = local_update_private_key
    uilogger.info(bundle)
    cmd = 'openssl smime -decrypt -in ' + bundle + ' -binary -inform DEM -inkey ' + key + ' -out /dev/null >> /dev/null 2>&1'
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    p.wait()
    exit_code = p.returncode
    uilogger.info(exit_code)

    if exit_code == 0:
        return True
    else:
        return False


def install_uploaded_update():
    file = [f for f in os.listdir(local_update_folder) if os.path.isfile(os.path.join(local_update_folder, f))][0]
    uilogger.info(file)

    uilogger.info('decrypting the update')
    bundle = local_update_folder + file
    key = local_update_private_key
    out = local_update_folder + "update.tar.gz"
    cmd = 'openssl smime -decrypt -in ' + bundle + ' -binary -inform DEM -inkey ' + key + ' -out ' + out
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    p.wait()
    exit_code = p.returncode
    uilogger.info(exit_code)

    if exit_code == 0:

        uilogger.info('decrypted')
        uilogger.info('untaring the update')
        update = local_update_folder + "update.tar.gz"
        cmd = 'tar -zxvf ' + update + ' -C ' + local_update_folder + ' --strip-components=2'
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        p.wait()
        exit_code = p.returncode
        uilogger.info(exit_code)

        if exit_code == 0:

            uilogger.info('untared')
            uilogger.info('triggering local update script')
            cmd = local_update_folder + 'local_update_install.sh'
            uilogger.info(cmd)
            local_update = subprocess.Popen(cmd,
                                            shell=True,
                                            stdout=subprocess.PIPE)
            exit_code = int(local_update.stdout.read())
            uilogger.info(exit_code)
            if exit_code == 0:
                uilogger.info('manually updated')
                return True

            else:
                uilogger.info('cannot manually update')
                return False

        else:
            uilogger.info('cannot untar')
            return False

    else:
        uilogger.info('cannot decrypt')
        return False


def get_static_ip_details(port_no):
    dongle_name = "dongle"+ port_no
    interface_name = dongle_info[dongle_name]['interface_name']
    interface_file_path = NETWORK_INTERFACE_FILE + '/' + interface_name
    ip_address = None
    interface = None
    netmask = None
    gateway =None
    dns = None
    alt_dns = None
    try:
        if os.path.isfile(interface_file_path):
            with open(interface_file_path, "r") as interface_file:
                words = [word for line in interface_file for word in line.split()]
            for index, word in enumerate(words):
                print index, word
                if word == 'address':
                    ip_address = words[index + 1]
                    print ip_address
                if word == 'iface':
                    interface = words[index + 1]
                if word == 'netmask':
                    netmask = words[index + 1]
                if word == 'gateway':
                    gateway = words[index + 1]
                if word == 'dns-nameservers':
                    dns = words[index + 1]
                    alt_dns = words[index + 2]
    except IndexError:
        pass
    msg = {"ip_address": ip_address, "netmask": netmask, "gateway": gateway, "dns": dns, "alternate_dns": alt_dns}
    return msg


def is_ip_address_valid(ip_address):
    '''checks only for ipv4 address'''
    try:
        socket.inet_pton(socket.AF_INET, ip_address)
    except AttributeError:  # no inet_pton here, sorry
        try:
            socket.inet_aton(ip_address)
        except socket.error:
            return False
        return ip_address.count('.') == 3
    except socket.error:  # not a valid address
        return False
    return True


def check_valid_address(ip, netmask, gateway, dns, alt_dns):
    if is_ip_address_valid(ip) and is_ip_address_valid(netmask) and is_ip_address_valid(gateway):
        try:
            if IPAddress(ip) and IPAddress(netmask) and IPAddress(gateway):
                if len(dns):
                    if not IPAddress(dns) or not is_ip_address_valid(dns):
                        return False
                if len(alt_dns):
                    if (not IPAddress(alt_dns)) or (not is_ip_address_valid(alt_dns)):
                        return False
                return True
            else:
                return False
        except (ValueError, netaddr.AddrFormatError) as e:
            return False
    else:
        return False


def set_static_ip_details(port_no, new_ip, new_netmask, new_gateway, new_dns, new_alt_dns):
    dongle_name = "dongle" + port_no
    interface_name = dongle_info[dongle_name]['interface_name']
    interface_file_path = NETWORK_INTERFACE_FILE + '/' + interface_name
    user_message = None
    error_msg = None
    if check_valid_address(new_ip, new_netmask, new_gateway, new_dns, new_alt_dns):
        if os.path.isfile(interface_file_path):
            print "file already exists will be replacing the file"
            os.remove(interface_file_path)
            interface_definition = 'allow-hotplug ' + interface_name + '\n' + \
                                       '\t iface ' + interface_name + ' inet static\n' + \
                                       '\t address ' + new_ip + '\n' + \
                                       ' \t netmask ' + new_netmask + '\n' + \
                                       ' \t gateway ' + new_gateway + '\n'
            if len(new_dns) or len(new_alt_dns):
                interface_definition = interface_definition + '\t dns-nameservers ' + new_dns + ' ' + new_alt_dns + '\n'

            with open(interface_file_path, "a") as interface_file:
                interface_file.seek(0)
                interface_file.truncate()
                interface_file.write(interface_definition)
                user_message = "Please unplug and plug in your device for changes to take effect"
                error_msg = None
        else:
            uilogger.info('failed tp set static ip: ' + interface_file_path + 'not found', __name__)
            user_message = "File not found"
            error_msg = "unsucessful"
    else:
        user_message = "Please check if values entered are valid"
        error_msg = "unsucessful"
    msg = {"ip_address": new_ip, "netmask": new_netmask, "gateway": new_gateway, "dns": new_dns,
           "alternate_dns": new_alt_dns, "user_message": user_message, "error_message": error_msg}
    return msg


def delete_static_ip_details(port_no):
    dongle_name = "dongle" + port_no
    interface_name = dongle_info[dongle_name]['interface_name']
    interface_file_path = NETWORK_INTERFACE_FILE + '/' + interface_name
    if os.path.isfile(interface_file_path):
        print "file already exists will be replacing the file"
        os.remove(interface_file_path)
        interface_definition = 'allow-hotplug' + ' ' + interface_name + '\n' + \
                               'iface' + ' ' + interface_name + ' ' + 'inet manual \n'

        with open(interface_file_path, "a") as interface_file:
            interface_file.seek(0)
            interface_file.truncate()
            interface_file.write(interface_definition)
            user_message = "Static settings are deleted. PLease unplug and plug"
            error_msg = None
    else:
        user_message = "Please check if values entered are valid"
        error_msg = "unsucessful"
    msg = {"ip_address": None, "netmask": None, "gateway": None, "dns": None, "alternate_dns": None, "user_message": user_message,
           "error_message": error_msg}
    return msg

