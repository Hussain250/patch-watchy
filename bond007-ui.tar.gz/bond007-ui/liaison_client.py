from twisted.internet.protocol import Factory, ReconnectingClientFactory
from twisted.protocols.basic import LineReceiver
from twisted.internet import reactor
import interface_manager
import time, sys
from ui_logger import uilogger

clientlist={}
SOCK_PATH = "/tmp/watchy"

class LiaisonClient(LineReceiver):
 
    def connectionMade(self):
        pass

    def connectionLost(self, reason):
        uilogger.info('liaisonclient connection lost')

    def closeReactor(self):
        reactor.stop()      #@UndefinedVariable
       
    def lineReceived(self, line):
        uilogger.debug(line)
        uilogger.info(line)
        interface_manager.currentState(self, line)
        
    def sendMessage(self, data):
        uilogger.info('liaisonclient sending data:')
        uilogger.info(data)
        self.sendLine(data)
        
    def stopConnection(self):
        uilogger.debug( "kill connection")
        self.transport.loseConnection()
        
class LiaisonClientFactory(ReconnectingClientFactory):
    """A factory for LogBots.

    A new protocol instance will be created each time we connect to the server.
    """

    def __init__(self):
        pass

    def buildProtocol(self, addr):
        liaisonclient = LiaisonClient()
        liaisonclient.factory = self
        clientlist[addr.name]=liaisonclient
        return liaisonclient

    def clientConnectionLost(self, connector, reason):
        """If we get disconnected, reconnect to server."""
        ReconnectingClientFactory.clientConnectionLost(self, connector, reason)

    def clientConnectionFailed(self, connector, reason):
        uilogger.error('Connection Failed:')
        uilogger.error(reason)
        ReconnectingClientFactory.clientConnectionLost(self, connector, reason)
        
    def startedConnecting(self,connector):
        pass


def initialise():
    uilogger.info('dongle sock path'+SOCK_PATH +"/dongle0.sock")
    f = LiaisonClientFactory()
    f.maxDelay= 5
    reactor.connectUNIX(SOCK_PATH +"/dongle0.sock", f)        #@UndefinedVariable
    reactor.connectUNIX(SOCK_PATH +"/dongle1.sock", f)        #@UndefinedVariable
    reactor.connectUNIX(SOCK_PATH +"/dongle2.sock", f)        #@UndefinedVariable
    reactor.connectUNIX(SOCK_PATH +"/dongle3.sock", f)        #@UndefinedVariable
    reactor.connectUNIX(SOCK_PATH +"/dongle4.sock", f)        #@UndefinedVariable
    reactor.connectUNIX(SOCK_PATH +"/dongle5.sock", f)        #@UndefinedVariable
    reactor.connectUNIX(SOCK_PATH +"/dongle6.sock", f)        #@UndefinedVariable
    reactor.connectUNIX(SOCK_PATH +"/dongle7.sock", f)        #@UndefinedVariable
    

