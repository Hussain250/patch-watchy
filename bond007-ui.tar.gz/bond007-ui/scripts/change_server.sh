#!/bin/bash

SRL_NO=$(cat /opt/watchy/bond007-id/serial.number)
touch /opt/watchy/bond007-ui/scripts/log.log
echo "$SRL_NO" > /opt/watchy/bond007-ui/scripts/log.log

cd /opt/watchy/bond007-ui/scripts

python update_maxwell_conf.py "$1" >> /opt/watchy/bond007-ui/scripts/log.log
NUM=${SRL_NO:0:1}
./reset_interface.sh "${NUM}x" >> /opt/watchy/bond007-ui/scripts/log.log
