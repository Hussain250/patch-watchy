#!/bin/bash

SERVER_NAME=""
if [[ "$1" == "chn01" ]]
then
        SERVER_NAME="maxchn01.watchy.in"
elif [[ "$1" == "del01" ]]
then
        SERVER_NAME="maxdel01.watchy.in"
elif [[ "$1" == "blr01" ]]
then
        SERVER_NAME="maxblr01.watchy.in"
elif [[ "$1" == "bom01" ]]
then
        SERVER_NAME="maxbom01.watchy.in"
else
        echo "Select the right server"
fi


SRL_NO=$(cat /opt/watchy/bond007-id/serial.number)
touch /opt/watchy/bond007-ui/scripts/log.log
echo "$SRL_NO" > /opt/watchy/bond007-ui/scripts/log.log

cd /opt/watchy/bond007-ui/scripts

python update_maxwell_conf.py "$SERVER_NAME" >> /opt/watchy/bond007-ui/scripts/log.log
NUM=${SRL_NO:0:1}
./reset_interface.sh "${NUM}x" >> /opt/watchy/bond007-ui/scripts/log.log
