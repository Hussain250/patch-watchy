#!/bin/bash

INET_DEV='/proc/net/dev'
TUN_INTERFACE='net'
#TUN_INTERFACE='wlan0'
TOTAL_TUN_INTERFACE=(`cat "$INET_DEV" | grep -c "$TUN_INTERFACE"`)
#TOTAL_TUN_INTERFACE=8

##### DO NOT EDIT BELOW THIS IF YOU ARE NOT THE AUTHOR #####

declare -a RX_NETS
declare -a RX_NETS_1
declare -a RX_NETS_2
declare -a TX_NETS
declare -a TX_NETS_1
declare -a TX_NETS_2

for ((NET_INT=0; NET_INT<"$TOTAL_TUN_INTERFACE"; NET_INT++))
do
        TEMP_RX=`cat "$INET_DEV" | grep "$TUN_INTERFACE"["$NET_INT"] | awk '{print $2}'`
        TEMP_TX=`cat "$INET_DEV" | grep "$TUN_INTERFACE"["$NET_INT"] | awk '{print $10}'`

#        TEMP_RX=`cat "$INET_DEV" | grep "$TUN_INTERFACE" | awk '{print $2}'`
#        TEMP_TX=`cat "$INET_DEV" | grep "$TUN_INTERFACE" | awk '{print $10}'`

        # converting bytes to bits
        TEMP_RX=$[$TEMP_RX * 8]
        TEMP_TX=$[$TEMP_TX * 8]

        # converting bits to mega bits
        TEMP_RX=`bc <<< "scale = 1; $TEMP_RX/(1024*1024)"`
        TEMP_TX=`bc <<< "scale = 1; $TEMP_TX/(1024*1024)"`

        RX_NETS_1["$NET_INT"]="$TEMP_RX"
        TX_NETS_1["$NET_INT"]="$TEMP_TX"
done

sleep 1

for ((NET_INT=0; NET_INT<"$TOTAL_TUN_INTERFACE"; NET_INT++))
do
        TEMP_RX=`cat "$INET_DEV" | grep "$TUN_INTERFACE"["$NET_INT"] | awk '{print $2}'`
        TEMP_TX=`cat "$INET_DEV" | grep "$TUN_INTERFACE"["$NET_INT"] | awk '{print $10}'`

#        TEMP_RX=`cat "$INET_DEV" | grep "$TUN_INTERFACE" | awk '{print $2}'`
#        TEMP_TX=`cat "$INET_DEV" | grep "$TUN_INTERFACE" | awk '{print $10}'`

        # converting bytes to bits
        TEMP_RX=$[$TEMP_RX * 8]
        TEMP_TX=$[$TEMP_TX * 8]

        # converting bits to mega bits
        TEMP_RX=`bc <<< "scale = 1; $TEMP_RX/(1024*1024)"`
        TEMP_TX=`bc <<< "scale = 1; $TEMP_TX/(1024*1024)"`

        RX_NETS_2["$NET_INT"]="$TEMP_RX"
        TX_NETS_2["$NET_INT"]="$TEMP_TX"
done

TOT_RX=0
TOT_TX=0

for ((NET_INT=0; NET_INT<"$TOTAL_TUN_INTERFACE"; NET_INT++))
do
    # allowing float
    TEMP_RX=`echo ${RX_NETS_2["NET_INT"]} - ${RX_NETS_1["NET_INT"]} | bc`
    TEMP_TX=`echo ${TX_NETS_2["NET_INT"]} - ${TX_NETS_1["NET_INT"]} | bc`

    # adding leading zero when < 1
    TEMP_RX=`printf "%02.1f\n" "$TEMP_RX"`
    TEMP_TX=`printf "%02.1f\n" "$TEMP_TX"`

    # adding the temp values for total rx and tx
    TOT_RX=`bc <<< "scale = 1; $TOT_RX+$TEMP_RX"`
    TOT_TX=`bc <<< "scale = 1; $TOT_TX+$TEMP_TX"`

    RX_NETS["$NET_INT"]="$TEMP_RX"
    TX_NETS["$NET_INT"]="$TEMP_TX"
done

echo ${RX_NETS[@]}'+'${TX_NETS[@]}'+'$TOT_RX'+'$TOT_TX