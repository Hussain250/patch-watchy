#!/bin/bash

# this script sets the ssid and passphrase given in the user interface
# and also restarts the hostapd service on any changes to the hostapd
# configurations file
	
set -x

OPT=$1
HOSTAPD_FILE='/etc/hostapd/hostapd.conf'

get_ssid_and_passphrase()
{
	SSID=`grep --only-matching --perl-regex "(?<=^ssid\=).*" "$HOSTAPD_FILE"`
	PASSPHRASE=`grep --only-matching --perl-regex "(?<=^wpa_passphrase\=).*" "$HOSTAPD_FILE"`
	
	echo "$SSID"+"$PASSPHRASE"
}

set_ssid_and_passphrase()
{
	
	NEW_SSID=$1
	NEW_PASSPHRASE=$2
	
	SSID=`grep --only-matching --perl-regex "(?<=^ssid\=).*" "$HOSTAPD_FILE"`
	PASSPHRASE=`grep --only-matching --perl-regex "(?<=^wpa_passphrase\=).*" "$HOSTAPD_FILE"`
	
	sed -i 's|='"$SSID"'|='"$NEW_SSID"'|g' "$HOSTAPD_FILE"
	sed -i 's|='"$PASSPHRASE"'|='"$NEW_PASSPHRASE"'|g' "$HOSTAPD_FILE"
}

reset_ssid_and_passphrase()
{
	
	FACTORY_SSID='ZifiLink'
	FACTORY_PASSPHRASE='qwaszx123'
	
	set_ssid_and_passphrase "$FACTORY_SSID" "$FACTORY_PASSPHRASE"
}

restart_service()
{
	service hostapd restart
	echo $?
}

if [[ "$OPT" == "GET" ]]
then
	get_ssid_and_passphrase
elif [[ "$OPT" == "SET" ]]
then
	set_ssid_and_passphrase $2 $3
	restart_service
elif [[ "$OPT" == "RESET" ]]
then
	reset_ssid_and_passphrase
	restart_service
fi
