#!/bin/bash

PUBLIC_KEY='/opt/watchy/ssl-keypair/log_dump_public.pem'
LOG_DUMP_DIR='/tmp/log_dump/'
mkdir -p "$LOG_DUMP_DIR"

date > "$LOG_DUMP_DIR"/date

# artifacts version
declare -a ARTIFACTS=("bond007-core" "bond007-ui" "bond007-netsettings" "tcp-intercept" "wvdial" "openvpn" "watchy-app-bundle")

TOTAL_ARTIFACTS=${#ARTIFACTS[@]}
for (( ARTIFACT=0; ARTIFACT<$TOTAL_ARTIFACTS; ARTIFACT++ ))
do
        dpkg -l ${ARTIFACTS[$ARTIFACT]} | grep ${ARTIFACTS[$ARTIFACT]} >> "$LOG_DUMP_DIR"version
        dpkg -s ${ARTIFACTS[$ARTIFACT]} >> "$LOG_DUMP_DIR"version
        echo '==============================================================================' >> "$LOG_DUMP_DIR"version
done

# network
route -n > "$LOG_DUMP_DIR"route_n
ip rule > "$LOG_DUMP_DIR"ip_rule
ip route > "$LOG_DUMP_DIR"ip_route
ip a > "$LOG_DUMP_DIR"ip_a
cat /etc/iproute2/rt_tables > "$LOG_DUMP_DIR"rt_tables
cat /proc/net/mptcp > "$LOG_DUMP_DIR"mptcp
cat /proc/net/mptcp_fullmesh > "$LOG_DUMP_DIR"mptcp_fullmesh

# system
free -h > "$LOG_DUMP_DIR"ram

# dongle
ls -al /dev/dongle* > "$LOG_DUMP_DIR"dongle 2>&1
lsusb > "$LOG_DUMP_DIR"lsusb

# log
cp -r /var/log/watchy "$LOG_DUMP_DIR"
cp -r /var/log/supervisor "$LOG_DUMP_DIR"
cp /var/log/syslog "$LOG_DUMP_DIR"
cp  /var/log/dmesg "$LOG_DUMP_DIR"

# conf
cp /opt/watchy/bond007-core/conf/brute_id_pair.cfg "$LOG_DUMP_DIR"
cp /opt/watchy/bond007-core/conf/esn_imei_map.cfg "$LOG_DUMP_DIR"
cp /opt/watchy/bond007-core/conf/maxwell.cfg "$LOG_DUMP_DIR"

# domain nameservers
cat /etc/resolv.conf > "$LOG_DUMP_DIR"resolv.conf
cat /etc/hosts > "$LOG_DUMP_DIR"hosts
cat /etc/network/interfaces > "$LOG_DUMP_DIR"interfaces

SERIAL_NUMBER=`cat /opt/watchy/bond007-id/serial.number`
LOG_NAME="log_""$SERIAL_NUMBER"'_'`date +%d-%m-%Y_%H:%M`
LOG_TAR="$LOG_NAME"'.tar.gz'

tar -czPf  /tmp/"$LOG_TAR" "$LOG_DUMP_DIR"

#encrypting log zip
openssl smime -encrypt -aes256 -in /tmp/"$LOG_TAR" -binary -outform DEM -out /tmp/"$LOG_NAME" "$PUBLIC_KEY"

rm -rf "$LOG_DUMP_DIR"
rm -f "$LOG_TAR"

echo "$LOG_NAME"