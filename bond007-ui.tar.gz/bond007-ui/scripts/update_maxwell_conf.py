import ConfigParser
import sys

CORE_CONFIG_PATH="/opt/watchy/bond007-core/conf/maxwell.cfg"
coreconfigfile = ConfigParser.ConfigParser()
coreconfigfile.read(CORE_CONFIG_PATH)

server_domain = [ x for x in coreconfigfile.get("all_maxwells", "domain").split(" ") if x ]
server_location = [ x for x in coreconfigfile.get("all_maxwells", "location").split(" ") if x ]
server_id = [ x for x in coreconfigfile.get("all_maxwells", "id").split(" ") if x ]

server = ""
all_servers_dict = []
for each_domain,each_location,each_id in zip(server_domain, server_location, server_id):
    if (sys.argv[1].strip() == each_ids.strip()):
        server = each_domain    

if not(server == ""):
    coreconfigfile.set("maxwells", "list", sys.argv[1])
    coreconfigfile.remove_section("maxchn01.watchy.in")
    coreconfigfile.remove_section("maxdel01.watchy.in")
    coreconfigfile.remove_section("maxblr01.watchy.in")
    coreconfigfile.remove_section("maxbom01.watchy.in")
    with open(CORE_CONFIG_PATH, 'w') as fp:
        coreconfigfile.write(fp)
    print("Setting the maxwel server to " + coreconfigfile.get("maxwells", "list"))
else:
    print("Error in getting the server")