import io
import os
import logging
from logging.handlers import RotatingFileHandler

log_dir = '/var/log/watchy/'
log_filename = log_dir + 'dongle_manager_ui.log'
log_format = logging.Formatter('%(asctime)s | %(levelname)s: %(message)s')
logger = None
max_bytes = 1000000
backup_count = 1
class uilogger:
    
    @staticmethod
    def initialize(level):
                    
        if os.path.exists(log_filename):
            os.remove(log_filename)
            io.open(log_filename, 'a+')
        else:
            io.open(log_filename, 'a+')

        global logger
        logger = logging.getLogger('bond007-ui')
        logger.setLevel(int(level))
        logger_file = RotatingFileHandler(log_filename, maxBytes=max_bytes, backupCount=backup_count)
        logger_file.setFormatter(log_format)
        logger.addHandler(logger_file)
        
                
    @staticmethod
    def debug(message):
        logger.debug(message)
    
    @staticmethod
    def info(message):
        logger.info(message)
        
    @staticmethod
    def warning(message):
        logger.warning(message)
                    
    @staticmethod
    def error(message):
        pass